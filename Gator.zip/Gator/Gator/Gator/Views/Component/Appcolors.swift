//
//  Appcolors.swift
//  Gator
//
//  Created by Foundation-009 on 30/06/25.
//

import SwiftUI

extension Color {
    static let appGreenLight = Color(red: 224/255, green: 245/255, blue: 242/255)
}
